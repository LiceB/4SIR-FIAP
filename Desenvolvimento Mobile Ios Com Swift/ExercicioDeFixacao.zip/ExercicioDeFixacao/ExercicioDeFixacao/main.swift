//
//  main.swift
//  ExercicioDeFixacao
//
//  Created by Usuário Convidado on 18/03/24.
//

import Foundation

var enfermeira = Enfermeira()
enfermeira.nome = "Alice"
enfermeira.salario = 2000.00
enfermeira.formada = false
enfermeira.CRE = 493578

print("Enfermeira \(enfermeira.nome) tem salário de \(enfermeira.salario), CRE \(enfermeira.CRE) e formada \(enfermeira.formada)")
