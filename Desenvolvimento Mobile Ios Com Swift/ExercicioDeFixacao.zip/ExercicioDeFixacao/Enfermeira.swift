//
//  Enfermeira.swift
//  ExercicioDeFixacao
//
//  Created by Usuário Convidado on 18/03/24.
//

import Cocoa

class Enfermeira: NSObject {
    var nome:String
    var salario:Float
    var formada:Bool
    var CRE:Int
    
    override init() {
        self.nome = ""
        self.salario = 0
        self.formada = true
        self.CRE = 0
    }
    
    init(nome: String, salario: Float, formada: Bool, CRE: Int) {
        self.nome = nome
        self.salario = salario
        self.formada = formada
        self.CRE = CRE
    }
    
    func medicar(paciente:String, medicamento:String) {
        print("O paciente \(paciente) foi medicado com \(medicamento)")
    }
    
    func verificarPressao(Pressao:Float)->Bool {
        if Pressao > 131 {
            return true
        } else {
            return false
        }
    }
    
    func medirFebre(Temperatura:Int)->String {
        if Temperatura > 38 {
            return "Está com febre"
        } else if Temperatura < 37 && Temperatura > 36 {
            return "Estado febril"
        } else {
            return "Estado normal"
        }
    }
    
    func contarPacientes(Paciente:Int)->Int {
        print("Hoje temos \(Paciente).")
    }

}
